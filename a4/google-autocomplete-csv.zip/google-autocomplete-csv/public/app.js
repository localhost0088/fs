const qEl = document.getElementById('q');
const langEl = document.getElementById('lang');
const countryEl = document.getElementById('country');
const listEl = document.getElementById('list');
const fetchBtn = document.getElementById('fetchBtn');
const downloadBtn = document.getElementById('downloadBtn');


async function fetchSuggestions() {
const q = qEl.value.trim();
const lang = langEl.value;
const country = countryEl.value;
if (!q) return;


listEl.innerHTML = '<li class="muted">Loading…</li>';
downloadBtn.disabled = true;


const params = new URLSearchParams({ q, lang, country });
const res = await fetch(`/api/suggest?${params.toString()}`);
if (!res.ok) {
listEl.innerHTML = '<li>Failed to fetch suggestions.</li>';
return;
}
const data = await res.json();
listEl.innerHTML = '';
data.suggestions.forEach((s) => {
const li = document.createElement('li');
li.textContent = s;
listEl.appendChild(li);
});


// enable CSV download
downloadBtn.disabled = data.suggestions.length === 0;
}


function downloadCSV() {
const q = qEl.value.trim();
const lang = langEl.value;
const country = countryEl.value;
if (!q) return;
const params = new URLSearchParams({ q, lang, country });
window.location.href = `/api/download?${params.toString()}`;
}


fetchBtn.addEventListener('click', fetchSuggestions);
qEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') fetchSuggestions(); });
downloadBtn.addEventListener('click', downloadCSV);