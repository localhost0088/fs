import express from 'express';
import axios from 'axios';
import { stringify } from 'csv-stringify';
import rateLimit from 'express-rate-limit';
import morgan from 'morgan';


const app = express();
const PORT = process.env.PORT || 3000;
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || '*';

// Basic security/rate limit
const limiter = rateLimit({
windowMs: 60 * 1000, // 1 minute
max: 60, // 60 requests per minute per IP
});

app.use(limiter);
app.use(morgan('dev'));
app.use(express.static('public'));
// CORS (loose by default; tighten for production)
app.use((req, res, next) => {
res.header('Access-Control-Allow-Origin', ALLOW_ORIGIN);
res.header('Access-Control-Allow-Methods', 'GET');
res.header('Access-Control-Allow-Headers', 'Content-Type');
next();
});


// Helper: fetch suggestions from Google’s endpoint
async function fetchSuggestions(query, lang = 'en', country = 'us') {
if (!query) return [];
// Firefox client returns JSON like: ["q", ["q a", "q b", ...]]
const url = 'https://suggestqueries.google.com/complete/search';
const params = {
client: 'firefox',q: query,hl: lang,gl: country
};
const { data } = await axios.get(url, { params, timeout: 8000 });
// data e.g. ["laptop", ["laptop stand","laptop bag", ...]]
if (Array.isArray(data) && Array.isArray(data[1])) {
return data[1];
}
return [];
}


// API: JSON suggestions
// GET /api/suggest?q=hello&lang=en&country=us
app.get('/api/suggest', async (req, res) => {
const { q, lang = 'en', country = 'us' } = req.query;
try {
const suggestions = await fetchSuggestions(String(q || ''), String(lang), String(country));
res.json({ query: q || '', suggestions });
} catch (err) {
console.error(err.message);
res.status(502).json({ error: 'Failed to fetch suggestions' });
}
});


// API: CSV download
// GET /api/download?q=hello&lang=en&country=us
app.get('/api/download', async (req, res) => {
const { q, lang = 'en', country = 'us' } = req.query;
const query = String(q || '');
try {
const suggestions = await fetchSuggestions(query, String(lang), String(country));


res.setHeader('Content-Type', 'text/csv; charset=utf-8');
res.setHeader('Content-Disposition', `attachment; filename="suggestions_${encodeURIComponent(query)}.csv"`);


// Write CSV streaming (columns: query, suggestion, index)
const stringifier = stringify({ header: true, columns: ['query', 'suggestion', 'index'] });
stringifier.pipe(res);


suggestions.forEach((s, i) => {
stringifier.write([query, s, i]);
});
stringifier.end();
} catch (err) {
console.error(err.message);
res.status(502).json({ error: 'Failed to fetch suggestions' });
}
});


app.listen(PORT, () => {
console.log(`Server running at http://localhost:${PORT}`);
});