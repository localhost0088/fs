import { Routes } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome';
import { ChildComponent } from './child/child';
import { CalculatorComponent } from './calculator/calculator';
import { LoginComponent } from './login/login';

export const routes: Routes = [
  { path: 'welcome', component: WelcomeComponent },   // page 1
  { path: 'button', component: ChildComponent },      // page 2
  { path: 'calculator', component: CalculatorComponent }, // page 3
  { path: 'login', component: LoginComponent },        // page 4
  { path: '', redirectTo: '/welcome', pathMatch: 'full' }
];
