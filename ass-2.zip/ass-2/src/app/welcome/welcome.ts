import { Component } from '@angular/core';

@Component({
  selector: 'app-welcome',
  standalone: true,
  template: `<h1>Welcome to School of Computer Science, NWC</h1>`
})
export class WelcomeComponent {}
