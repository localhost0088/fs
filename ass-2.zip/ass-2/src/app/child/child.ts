import { Component } from '@angular/core';

@Component({
  selector: 'app-child',
  standalone: true,
  templateUrl: './child.html',
  styleUrls: ['./child.css']
})
export class ChildComponent {

  showAlert() {
    alert('Hello! This is an alert message.');
  }

}
