import java.util.LinkedList;

public class ReverseChar {
    public static void main(String[] args) {

        // Create a linked list to store the reversed strings
        LinkedList<String> reversedList = new LinkedList<>();

        // Original strings
        String[] words = {"Hello", "World", "Java", "DSA"};

        // Reverse the characters of each string and add to the linked list
        for (String word : words) {
            // Reverse the current string
            String reversedWord = new StringBuilder(word).reverse().toString();
            
            // Add the reversed string to the list
            reversedList.add(reversedWord);
        }

        // Display the linked list
        System.out.println("LinkedList with characters reversed:");
        for (String item : reversedList) {
            System.out.println(item);
        }
    }
}

